#include "clases.h"

int horaActual(){
Tiempo tiempo;
return tiempo.getHora();
}

Fecha fechaActual(){
Tiempo tiempo;
return tiempo.getFecha();
}
