#pragma once
/// ARCHIVOS DE TEXTO

/// IDS
const char ARCHIVO_ID_EMPLEADOS[30] = "id_empleados.dat";
const char ARCHIVO_ID_PRODUCTOS[30] = "id_productos.dat";
const char ARCHIVO_ID_FACTURAS[30] = "id_facturas.dat";

/// BBDD
const char ARCHIVO_EMPLEADOS[30] = "empleados.dat";
const char ARCHIVO_PRODUCTOS[30] = "productos.dat";
const char ARCHIVO_FACTURAS[30] = "facturas.dat";
const char ARCHIVO_MESAS_LOCAL[30] = "mesasLocal.dat";
