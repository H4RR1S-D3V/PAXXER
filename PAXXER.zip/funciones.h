#pragma once
#include "clases.h"

int horaActual();

Fecha fechaActual();
